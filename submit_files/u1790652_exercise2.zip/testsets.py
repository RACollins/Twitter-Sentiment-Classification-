testsets = ['twitter-test1.txt', 'twitter-test2.txt', 'twitter-test3.txt']
#testsets = ['twitter-dev-data.txt'] # You may uncomment this line while you are experimenting with your classifier
